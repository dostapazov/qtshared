QDeviceWatcher can detect usb storage add and remove event.
Tested on linux (>= 2.6), windows(mingw and msvc) and OSX(buggy).

License under LGPL 2.1 or later

Screenshot
-----

![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/ubuntu.png              "Ubuntu non-debug")
![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/ubuntu-gui-debug.png    "Ubuntu gui debug")
![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/win7.png                "Win7 non-debug")
![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/win7-gui-debug.png      "Win7 gui debug")
![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/wince-emu-gu.png        "WinCE emulater")

